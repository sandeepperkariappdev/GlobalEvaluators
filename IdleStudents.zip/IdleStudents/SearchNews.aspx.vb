﻿
Partial Class SearchNews
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        getRSSFeed("http://news.google.co.in/news?hl=en&gl=in&q=jio&um=1&ie=UTF-8&output=rss", gvln1)

    End Sub


    Private Function getRSSFeed(ByVal url As String, ByVal gvLiveNews As GridView) As String
        Dim cachename = "news and events"
        Dim myxml As XmlDataSource = New XmlDataSource


        If IsNothing(Cache(cachename)) Then
            '  div_err.InnerHtml = "if cache is null then fetch"
            myxml = New XmlDataSource  'myxml is null so reset it
            myxml.DataFile = url
            myxml.XPath = "rss/channel/item"

            Try
                Cache.Insert(cachename, myxml, Nothing, Now.AddMilliseconds(200), TimeSpan.Zero)
                'nameof ur cache, datasource, null , no of minutes or hours to survive, timespan
                gvLiveNews.DataSource = myxml
                gvLiveNews.DataBind()
                '  lbError.Visible = False
                Return "1"
            Catch ex As Exception
                'gvLiveNews.Visible = False
                Return "Unable to get Portion of Live News Feed from internet. Service shall be restored shortly."
            End Try
        Else
            myxml = CType(Cache.Item(cachename), XmlDataSource)
            '  div_err.InnerHtml = "Getting from cache"
            gvLiveNews.DataSource = myxml
            gvLiveNews.DataBind()
            Return "1"
        End If
    End Function

End Class
