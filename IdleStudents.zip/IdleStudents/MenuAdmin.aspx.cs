﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.WebControls;
using DataAccessLayer;
public partial class MenuAdmin : System.Web.UI.Page
{
    DataAccessLayer.Dbhelper helper = new Dbhelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["AdminUserId"] == "" || Session["AdminUserId"] == null)
            {
                Response.Redirect("AdminLogin.aspx");

            }
            else
            {
                trMenu.Visible = false;
                trBtnAdd.Visible = false;
                BindDropdownList();
            }

        }

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        string url = string.Empty;
        
        if(ddlMenu.SelectedItem.Text.Contains("News"))
        {
            url = "WhiteNews.aspx";

        }

        if (ddlMenu.SelectedItem.Text.Contains("Blogs"))
        {
            url = "Blogs.aspx";
        }

         
        int rec =0;
        if (Convert.ToInt32(lblsno.Text) > 0)
        {
           // rec = helper.UpdateAdminChildMenu(Convert.ToInt32(lblsno.Text), Convert.ToInt32(ddlMenu.SelectedItem.Value), txtDesc.Text, url);
        }

        else
        {
            // SqlCommand SqlCmd = new SqlCommand("insert into dbo.AdminChildMenu values("+Convert.ToInt32(ddlMenu.SelectedItem.Value)+","+ "'"+txtDesc.Text+"',"+ "'" + txtDesc.Text + "',GETDATE(), GETDATE(),'"+ url.ToString() +"? Val=" + txtDesc.Text+"')", sqlConn);
            rec = helper.InsertAdminChildMenu(Convert.ToInt32(ddlMenu.SelectedItem.Value), txtDesc.Text, url);
        }
        if(rec > 0)
        {
            BindGrid();
        }
        trMenu.Visible = false;
        trBtnAdd.Visible = false;
        btnSearch.Visible = true;

    }
    protected void lnkbtnAdd_Click(object sender, EventArgs e)
    {
        trMenu.Visible = true;
        trBtnAdd.Visible = true;
        btnSearch.Visible = false;
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        trMenu.Visible = false;
        trBtnAdd.Visible = false;
        btnSearch.Visible = true;
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        BindGrid();
        trMenu.Visible = false;
        trBtnAdd.Visible = false;
    }

    private void BindGrid()
    {
        DataSet dsList = new DataSet();
        dsList = helper.BindAdminChild(Convert.ToInt32(ddlMenu.SelectedItem.Value));

        if (dsList.Tables[0].Rows.Count > 0)
        {
            gvMenus.DataSource = dsList.Tables[0];
            gvMenus.DataBind();
        }
        else
        {
            gvMenus.Dispose();

        }
        dsList.Dispose();

    }

    private void BindDropdownList()
    {
       DataSet dsList = new DataSet();
       dsList = helper.BindDropDownList();

        if (dsList.Tables[0].Rows.Count > 0)
        {
            ddlMenu.DataSource = dsList;
            ddlMenu.DataTextField = "MenuName";
            ddlMenu.DataValueField = "MenuId";
            ddlMenu.DataBind();
        }
        ddlMenu.Items.Insert(0, "--Select--");
        dsList.Dispose();
        ddlMenu.SelectedIndex = ddlMenu.Items.IndexOf(ddlMenu.Items.FindByText("--Select--"));
    }

    protected void lnkChildMenu_Click(object sender, EventArgs e)
    {
        ImageButton btn = (ImageButton)sender;
        DataSet dsList = new DataSet();
        //dsList = helper.GetAdminChildMenuDetails(btn.CommandArgument);

       /*  if (dsList.Tables[0].Rows.Count > 0)
         {
             trMenu.Visible = true;
             trBtnAdd.Visible = true;
             btnSearch.Visible = false;
             txtDesc.Text = dsList.Tables[0].Rows[0]["ChildMenuName"].ToString();
             lblsno.Text = dsList.Tables[0].Rows[0]["childMenuId"].ToString();
         }*/
    }

    protected void lnkChildMenuDel_Click(object sender, EventArgs e)
    {
        ImageButton btn = (ImageButton)sender;
        int rec = helper.DeleteAdminMenu(Convert.ToInt32(btn.CommandArgument));
       
        if (rec > 0)
        {
            BindGrid();
        }

    }
}