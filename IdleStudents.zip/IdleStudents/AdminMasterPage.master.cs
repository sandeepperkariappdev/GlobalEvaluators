﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminMasterPage : System.Web.UI.MasterPage
{
    SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["SqlConnectionDb"].ToString());
    DataSet dsList = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDropdownList();
        }
    }
    
    private void BindDropdownList()
    {
        sqlConn.Open();
        SqlCommand SqlCmd = new SqlCommand("select * from AdminMenuMaster", sqlConn);
        SqlDataAdapter sqlDap = new SqlDataAdapter(SqlCmd);
        sqlDap.Fill(dsList);
        sqlConn.Close();


        if (dsList.Tables[0].Rows.Count > 0)
        {
            ddlMenu.DataSource = dsList;
            ddlMenu.DataTextField = "MenuName";
            ddlMenu.DataValueField = "MenuId";
            ddlMenu.DataBind();
        }
        ddlMenu.Items.Insert(0, "--Select--");
        dsList.Dispose();
        ddlMenu.SelectedIndex = ddlMenu.Items.IndexOf(ddlMenu.Items.FindByText("--Select--"));
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        Session["Content"] = txtSearch.Value;
        if (ddlMenu.SelectedItem.Text.Contains("News"))
        {
            Response.Redirect("WhiteNews.aspx");
        }

        else if (ddlMenu.SelectedItem.Text.Contains("Blogs"))
        {
            Response.Redirect("Blogs.aspx");
        }
    }

    protected void btnUpdateMenu_Click(object sender, EventArgs e)
    {
        if(Session["AdminUserId"] != null ){
            Response.Redirect("MenuAdmin.aspx");
        }
    }


    protected void btnUpdateNewsContent_Click(object sender, EventArgs e)
    {
        if (Session["AdminUserId"] != null)
        {
            Response.Redirect("NewsContent.aspx");
        }
    }
    
}

