﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Text;
using DataAccessLayer;
public partial class WhiteInsideMasterPage : System.Web.UI.MasterPage
{
   // SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlConnectionDb"].ToString());
    SqlConnection sqlConn = new SqlConnection(ConfigurationSettings.AppSettings["SqlConnectionDb"].ToString());
    DataSet dsList = new DataSet();
    DataTable dtMenus = new DataTable();
    protected string ContentType;
    DataAccessLayer.Dbhelper dbhelper = new Dbhelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           BindGrid();
            BindGridBlogs();
            BindDropdownList();
          
        }
    }



    private void BindGrid()

    {

        sqlConn.Open();
        SqlCommand SqlCmd = new SqlCommand("select * from dbo.AdminChildMenu where ParentMenuId in (select MenuId from AdminMenuMaster where MenuName = 'NewsAndEvents')", sqlConn);
        SqlDataAdapter sqlDap = new SqlDataAdapter(SqlCmd);
        sqlDap.Fill(dsList);
        sqlConn.Close();

        if (dsList.Tables[0].Rows.Count > 0)
        {
            
            dlList.DataSource = dsList.Tables[0];
            dlList.DataBind();
        }
        else
        {
            dlList.Dispose();

        }
        dsList.Clear();
        dsList.Dispose();

    }
    protected void lnlRef_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;
        Response.Redirect("WhiteNews.aspx?Id=" + Convert.ToInt32(btn.CommandArgument));
    }

    private void BindGridBlogs()

    {

        sqlConn.Open();
        SqlCommand SqlCmd = new SqlCommand("select * from dbo.AdminChildMenu where ParentMenuId in (select MenuId from AdminMenuMaster where MenuName = 'Blogs')", sqlConn);
        SqlDataAdapter sqlDap = new SqlDataAdapter(SqlCmd);
        sqlDap.Fill(dsList);
        sqlConn.Close();

        if (dsList.Tables[0].Rows.Count > 0)
        {
            dllBlogs.DataSource = dsList.Tables[0];
            dllBlogs.DataBind();
        }
        dsList.Clear();
        dsList.Dispose();

    }
    private void BindDropdownList()
    {
        sqlConn.Open();
        SqlCommand SqlCmd = new SqlCommand("select * from AdminMenuMaster", sqlConn);
        SqlDataAdapter sqlDap = new SqlDataAdapter(SqlCmd);
        sqlDap.Fill(dtMenus);
        sqlConn.Close();


        if (dtMenus.Rows.Count > 0)
        {
            StringBuilder sb = new StringBuilder();
            foreach (DataRow dr in dtMenus.Rows)
            {
                if (dr[1].ToString() != "")
                {
                    sb.Append("<li><a href=" + "\"" + "#" + dr[1].ToString() + "\"" + ">" + dr[1].ToString() + "</a></li>");
                }
            }
            menuItems.InnerHtml = sb.ToString();
        }
       
    }


    protected void btnLogin_Click(object sender, EventArgs e)
    {
      DataSet dsList = new DataSet();
        dsList = dbhelper.GetLoginDetails(txtUserId.Value,txtPwd.Value);

        if (dsList.Tables[0].Rows.Count > 0)
        {
            Session["userid"] = txtUserId.Value;
            Response.Redirect("Home.aspx");
        }
       
      
    }




    protected void txtSearch_TextChanged(object sender, EventArgs e)
    {
        Session["SearchUrl"] = "http://news.google.co.in/news?hl=en&gl=in&q=" + txtSearch.Text + "&um=1&ie=UTF-8&output=rss";

        Response.Redirect("WhiteNews.aspx");

    }
}
