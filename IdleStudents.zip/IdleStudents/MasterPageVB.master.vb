﻿
Partial Class MasterPageVB
    Inherits System.Web.UI.MasterPage
End Class

