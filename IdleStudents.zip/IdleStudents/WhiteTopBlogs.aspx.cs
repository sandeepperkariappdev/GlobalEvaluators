﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using DataAccessLayer;
public partial class WhiteTopBlogs : System.Web.UI.Page
{
    DataAccessLayer.Dbhelper helper = new Dbhelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           
            BindGrid();
            BindCommentsGrid();
        }
    }

    private void BindGrid()
    {

        DataSet dsContent = new DataSet();
        dsContent = helper.BindContent(Convert.ToInt32(Session["BlogId"]));

        if (dsContent.Tables[0].Rows.Count > 0)
        {
            gvBlogs.DataSource = dsContent.Tables[0];
            gvBlogs.DataBind();
        }
        else
        {
            gvBlogs.Dispose();

        }
        dsContent.Clear();
        dsContent.Dispose();

    }

    private void BindCommentsGrid()
    {
        DataSet dsList = new DataSet();
        dsList = helper.BindComments(Convert.ToInt32(Session["BlogId"]));

        if (dsList.Tables[0].Rows.Count > 0)
        {
            gvComments.DataSource = dsList.Tables[0];
            gvComments.DataBind();
        }
        else
        {
            gvBlogs.Dispose();

        }
        dsList.Clear();
        dsList.Dispose();

    }
    protected void btnOk_Click(object sender, EventArgs e)
    {
        if (Session["userid"] != null)
        {
            int retValue = helper.InsertComments(taComments.Value, Convert.ToInt32(Session["BlogId"]));
            BindCommentsGrid();

        }
        
    }
}
