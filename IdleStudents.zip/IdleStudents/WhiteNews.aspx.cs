﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class WhiteNews : System.Web.UI.Page
{
    DataAccessLayer.Dbhelper helper = new DataAccessLayer.Dbhelper();
    protected string url;
    DataSet dsUrl = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
           // BindGrid();
           // XmlDataSource1.Dispose();
           
         //   XmlDataSource1.DataFile = "http://news.google.co.in/news?pz=1&cf=all&ned=us&topic=Science&output=rss";
            //   XmlDataSource1.DataFile = "http://news.google.co.in/news?pz=1&cf=all&ned=us&topic=Science&output=rss";
         //   XmlDataSource1.DataFile = "https://news.google.co.in/news?pz=1&cf=all&ned=in&hl=technology&topic=t&output=rss";
            XmlDataSource myxml = new XmlDataSource();
            string cachename = "news and events";
            if (Session["SearchUrl"]!= null)
            {
               
                myxml.DataFile = Session["SearchUrl"].ToString();
              

            }

            else
            {
                dsUrl = helper.BindNewsfeed(Convert.ToInt32(Request.QueryString["Id"]));
                myxml.DataFile = dsUrl.Tables[0].Rows[0]["UrlLink"].ToString();
                
                    lblCategory.Text = dsUrl.Tables[0].Rows[0].ItemArray[3] + "- News";

                
            }

            myxml.XPath = "rss/channel/item";
            Cache.Insert(cachename, myxml, null, DateTime.Now.AddMilliseconds(200), TimeSpan.Zero);
            gvln1.DataSource = myxml;
            gvln1.DataBind();


        }
    }

    //private void BindGrid()
    //{

    //    DataSet dsContent = new DataSet();
    //    if (Request.Url.ToString().Contains("Val"))
    //    {
    //        dsContent= helper.BindMenuContent(Request.QueryString["Val"].ToString());
    //    }

    //    else
    //    {
    //        dsContent = helper.BindMainSearch(Session["Content"].ToString());
    //    }

    //    if (dsContent.Tables[0].Rows.Count > 0)
    //    {
    //        dlNews.DataSource = dsContent.Tables[0];
    //        dlNews.DataBind();
    //    }
    //    else
    //    {
    //        dlNews.Dispose();

    //    }

    //    dsContent.Clear();
    //    dsContent.Dispose();


    //}
}