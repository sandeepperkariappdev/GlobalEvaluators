﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
public partial class WhiteMasterPage : System.Web.UI.MasterPage
{
    SqlConnection sqlConn = new SqlConnection(ConfigurationManager.ConnectionStrings["SqlConnectionDb"].ToString());
    DataSet dsList = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
            BindGridBlogs();
        }
    }
   
    private void BindGrid()

    {

        sqlConn.Open();
        SqlCommand SqlCmd = new SqlCommand("select * from dbo.AdminChildMenu where ParentMenuId in (select MenuId from AdminMenuMaster where MenuName = 'NewsAndEvents')", sqlConn);
        SqlDataAdapter sqlDap = new SqlDataAdapter(SqlCmd);
        sqlDap.Fill(dsList);
        sqlConn.Close();

        if (dsList.Tables[0].Rows.Count > 0)
        {
            dlList.DataSource = dsList.Tables[0];
            dlList.DataBind();
        }
        else
        {
            dlList.Dispose();

        }
        dsList.Dispose();

    }
    private void BindGridBlogs()

    {

        sqlConn.Open();
        SqlCommand SqlCmd = new SqlCommand("select * from dbo.AdminChildMenu where ParentMenuId in (select MenuId from AdminMenuMaster where MenuName = 'Blogs')", sqlConn);
        SqlDataAdapter sqlDap = new SqlDataAdapter(SqlCmd);
        sqlDap.Fill(dsList);
        sqlConn.Close();

        if (dsList.Tables[0].Rows.Count > 0)
        {
            dllBlogs.DataSource = dsList.Tables[0];
            dllBlogs.DataBind();
        }
        dsList.Clear();
        dsList.Dispose();

    }


}
