﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.UI.WebControls;
using DataAccessLayer;
using System.IO;

public partial class NewsContent : System.Web.UI.Page
{
    DataAccessLayer.Dbhelper helper = new Dbhelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["AdminUserId"] == "" || Session["AdminUserId"] == null)
            {
                Response.Redirect("AdminLogin.aspx");

            }
            else
            {
                trMenu.Visible = false;
                trBtnAdd.Visible = false;
                trContent.Visible = false;
                trFreeTextBox.Visible = false;

                BindDropdownList();
            }
        }

    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
      
      
        int rec;
        if (Convert.ToInt32(lblsno.Text) > 0)
        {
            rec = helper.UpdateContent(txtDesc.Text,FreeTextBox1.Text,Convert.ToInt32(lblsno.Text));
        }

        else
        {
            flUpload.SaveAs(Server.MapPath("~/Uploads/") + flUpload.FileName);
            rec = helper.InsertContent(Convert.ToInt32(ddlCategory.SelectedItem.Value), txtDesc.Text, FreeTextBox1.Text, "Uploads/" + flUpload.FileName);
        }
        if (rec > 0)
        {
            BindGrid();
        }
        trMenu.Visible = false;
        trBtnAdd.Visible = false;
        trContent.Visible = false;
        trFreeTextBox.Visible = false;
        btnSearch.Visible = true;
        trClickAdd.Visible = true;
    }
    protected void lnkbtnAdd_Click(object sender, EventArgs e)
    {
        trMenu.Visible = true;
        trBtnAdd.Visible = true;
        trContent.Visible = true;
        trFreeTextBox.Visible = true;
        btnSearch.Visible = false;
        trClickAdd.Visible = false;
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        BindGrid();
        trMenu.Visible = false;
        trBtnAdd.Visible = false;
        trContent.Visible = false;
        trFreeTextBox.Visible = false;
    }

    private void BindGrid()
    {
        DataSet dslist = new DataSet();
        dslist = helper.BindGrid(Convert.ToInt32(ddlCategory.SelectedItem.Value));
        if (dslist.Tables[0].Rows.Count > 0)
        {
            gvMenus.DataSource = dslist.Tables[0];
            gvMenus.DataBind();
        }
        else
        {
            gvMenus.Dispose();

        }
        dslist.Dispose();

    }

    private void BindDropdownList()
    {
        DataSet dslist = new DataSet();
        dslist = helper.BindDropDownList();

        if (dslist.Tables[0].Rows.Count > 0)
        {
            ddlMenu.DataSource = dslist;
            ddlMenu.DataTextField = "MenuName";
            ddlMenu.DataValueField = "MenuId";
            ddlMenu.DataBind();
        }
        ddlMenu.Items.Insert(0, "--Select--");
        dslist.Dispose();
        ddlMenu.SelectedIndex = ddlMenu.Items.IndexOf(ddlMenu.Items.FindByText("--Select--"));
    }



    private void BindDropdownChildList()
    {
        DataSet dslist = new DataSet();
        dslist = helper.BindChildDropDownList(Convert.ToInt32(ddlMenu.SelectedItem.Value));

        if (dslist.Tables[0].Rows.Count > 0)
        {
            ddlCategory.DataSource = dslist;
            ddlCategory.DataTextField = "ChildMenuName";
            ddlCategory.DataValueField = "ChildMenuId";
            ddlCategory.DataBind();
        }
        ddlCategory.Items.Insert(0, "--Select--");
        dslist.Dispose();
        ddlCategory.SelectedIndex = ddlCategory.Items.IndexOf(ddlCategory.Items.FindByText("--Select--"));
    }



    protected void lnkChildMenu_Click(object sender, EventArgs e)
    {
        ImageButton btn = (ImageButton)sender;
         DataSet dsList = new DataSet();
         dsList = helper.GetMenuContent(btn.CommandArgument);

        if (dsList.Tables[0].Rows.Count > 0)
        {
           
           txtDesc.Text = dsList.Tables[0].Rows[0]["Header"].ToString();
           FreeTextBox1.Text = dsList.Tables[0].Rows[0]["Content"].ToString();
           trMenu.Visible = true;
           trBtnAdd.Visible = true;
           trContent.Visible = true;
           trFreeTextBox.Visible = true;
           btnSearch.Visible = false;
           trClickAdd.Visible = false;
           lblsno.Text = dsList.Tables[0].Rows[0]["sno"].ToString();


        }    
     }

    protected void lnkChildMenuDel_Click(object sender, EventArgs e)
    {
        ImageButton btn = (ImageButton)sender;
        int rec = helper.DeleteContent(Convert.ToInt32(btn.CommandArgument)); 
        if (rec > 0)
        {
            BindGrid();
        }

    }

    protected void ddlMenu_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindDropdownChildList();
    }
}