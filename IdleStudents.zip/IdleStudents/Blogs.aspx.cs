﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Blogs : System.Web.UI.Page
{
    SqlConnection sqlConn = new SqlConnection(ConfigurationManager.AppSettings["SqlConnectionDb"].ToString());
    DataSet dsList = new DataSet();


    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrid();
        }
        if (Request.Url.ToString().Contains("Val"))
        {
            lblCategory.Text = Request.QueryString["Val"].ToString() + "-Blogs";
           
        }
        else
        {
            lblCategory.Text = "Search Blogs";
        }
    }

    private void BindGrid()
    {
        sqlConn.Open();
        if (Request.Url.ToString().Contains("Val"))
        {
            SqlCommand SqlCmd = new SqlCommand("select * from dbo.MenuContent where childMenuId in (select childmenuId from dbo.AdminchildMenu where ChildMenuName ='" + Request.QueryString["Val"].ToString() + "')", sqlConn);
            SqlDataAdapter sqlDap = new SqlDataAdapter(SqlCmd);
            sqlDap.Fill(dsList);
          
       }

        else
        {
            SqlCommand SqlCmd = new SqlCommand("select * from dbo.MenuContent where content like " + "'%" + Session["Content"] + "%' and ChildMenuId in (select ChildMenuId from AdminChildMenu where ParentMenuId=2)", sqlConn);
            SqlDataAdapter sqlDap = new SqlDataAdapter(SqlCmd);
            sqlDap.Fill(dsList);
            
            
        }
        sqlConn.Close();

        if (dsList.Tables[0].Rows.Count > 0)
        {
            dlBlogs.DataSource = dsList.Tables[0];
            dlBlogs.DataBind();
        }
        else
        {
            dlBlogs.Dispose();

        }
        dsList.Clear();
        dsList.Dispose();

    }


    protected void lnkBlogs_Click(object sender, EventArgs e)
    {
        LinkButton btn = (LinkButton)sender;

        Session["BlogId"] = btn.CommandArgument;
        Response.Redirect("WhiteTopBlogs.aspx");

    }
}