﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        loginUser.Visible = true;
        loginPassword.Visible = true;
        trBtnLogin.Visible = true;
        trBtnItem.Visible = false;
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Session["AdminUserId"] = txtUserId.Text;
        //Response.Redirect("MenuAdmin.aspx");
        loginUser.Visible = false;
        loginPassword.Visible = false;
        trBtnLogin.Visible = false;
        trBtnItem.Visible = true;
    }
    protected void btnUpdateMenu_Click(object sender, EventArgs e)
    {
        if (Session["AdminUserId"] != null)
        {
            Response.Redirect("MenuAdmin.aspx");
        }
    }
    protected void btnUpdateNewsContent_Click(object sender, EventArgs e)
    {
        if (Session["AdminUserId"] != null)
        {
            Response.Redirect("NewsContent.aspx");
        }
    }
}