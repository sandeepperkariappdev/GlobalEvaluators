
/*
 * re-public
 */

 export const RE_PUBLIC_URL = '';

/*
 *  ENDPOINTS
 */

// RE AUTH
export const LOGIN_USER_API = RE_PUBLIC_URL+'auth/login';
export const LOGOUT_USER_API = RE_PUBLIC_URL+'auth/logout';
